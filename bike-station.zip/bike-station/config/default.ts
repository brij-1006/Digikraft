export default {
  port: 1337,
  dbUri: "mongodb+srv://new-test-1:BbBb100685@cluster0.jalkq.mongodb.net/Digikraft",
  saltWorkFactor: 10,
  accessTokenTtl: "15m",
  refreshTokenTtl: "1y",
  accessTokenPrivateKey: ``,
  accessTokenPublicKey: ``,
  refreshTokenPrivateKey: ``,
  refreshTokenPublicKey: ``,
};
